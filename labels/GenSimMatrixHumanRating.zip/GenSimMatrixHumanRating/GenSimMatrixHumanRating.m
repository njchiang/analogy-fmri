% calculate similarity matrix for fMRI encoding analysis

% step 1: read in raw human ratings from Jergen data set
% step 2: adding a constant for Contrast-contrary and contrast-directional relations to remove the negative values. 
% step 3: normalize the rating for each relation to make the sum as 1
% step 4: determine the min value, and take the half of the min value as the similarity for the relations in the same category

clear all; 
load('humanrating.mat');

relnum = size(humanrating,2); 
for ri = 1:relnum 
    minval(ri) = min(humanrating(:,ri)); 
end;

rating = humanrating; 

%% add a constant to remove negative values for two relations
minvalall = 1.6;
relsel = [4 5];
for i = relsel
    rating(:,i) = rating(:,i)-minval(i)+minvalall;
end;

%% normalize ratings within a relation, make the sum as 1
for ri = 1:relnum
    sumval(ri) = sum(rating(:,ri));
    ratingnorm(:,ri) = rating(:,ri)/sumval(ri);
end;
    
for ri = 1:relnum 
    minval1(ri) = min(ratingnorm(:,ri)); 
end;
minvalall = min(minval1); 

%% generate similarity matrix
relcat = [1 1 1 2 2 2 3 3 3];
wordnumperrel = size(rating,1);


% method 1: put the half of the min value across all the norm-ratings to
% relations in the same category, put zero to the remaining relations in
% different caterory
relcatnum = 3; 
cattemp = [ 1 1 1 0 0 0 0 0 0; 0 0 0 2 2 2 0 0 0; 0 0 0 0 0 0 3 3 3];
relcatlabel = kron(cattemp, ones(wordnumperrel*relcatnum,1)); 
for ri = 1:relnum
    wordindx = (ri-1)*wordnumperrel+1:ri*wordnumperrel;
    relcatlabel(wordindx,ri) = ratingnorm(:,ri);  
end;

for i = 1:3
    [tempi, tempj] = find(relcatlabel==i); 
    for j= 1:length(tempi)
        relcatlabel(tempi(j),tempj(j)) = minvalall/2;
    end;
end;

simmat = relcatlabel;
save('simmathuman1.mat','simmat'); 

  
